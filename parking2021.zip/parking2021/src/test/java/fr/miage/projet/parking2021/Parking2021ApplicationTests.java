package fr.miage.projet.parking2021;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Parking2021ApplicationTests {

	@Test
	void contextLoads() {
	}

}
